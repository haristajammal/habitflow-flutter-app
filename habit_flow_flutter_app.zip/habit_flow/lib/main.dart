import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';
void main() {
  runApp(HabitFlowApp());
}

class HabitFlowApp extends StatefulWidget {
  HabitFlowApp({super.key});
  @override
  State<HabitFlowApp> createState() => _HabitFlowAppState();
}

class _HabitFlowAppState extends State<HabitFlowApp> {
  bool isDark = true;
  @override
  void initState() {
    super.initState();
    loadTheme();
  }

  // Load saved theme
  Future<void> loadTheme() async {
    final prefs = await SharedPreferences.getInstance();

    setState(() {
      isDark = prefs.getBool('isDark') ?? true;
    });
  }

  // Change and save theme
  Future<void> toggleTheme() async {
    setState(() {
      isDark = !isDark;
    });

    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('isDark', isDark);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'HabitFlow by Haris',

      themeMode: isDark ? ThemeMode.dark : ThemeMode.light,

      // Dark Theme
      darkTheme: ThemeData(
        brightness: Brightness.dark,

        scaffoldBackgroundColor: Color(0xFF121212),

        colorScheme: ColorScheme.dark(
          primary: Color(0xFFD4AF37),
          secondary: Color(0xFFE6C76A),
          surface: Color(0xFF1C1C1C),
        ),

        useMaterial3: true,
      ),

      // Light Theme
      theme: ThemeData(
        brightness: Brightness.light,
        scaffoldBackgroundColor: Color(0xFFFFFDF5),
        colorScheme: ColorScheme.light(
          primary: Color(0xFFB8962E),
          secondary: Color(0xFFD4AF37),
          surface: Color(0xFFFFFFFF),
        ),
        useMaterial3: true,
      ),

      home: HomeScreen(
        isDark: isDark,
        onThemeToggle: toggleTheme,
      ),
    );
  }
}
class HomeScreen extends StatefulWidget {
  final bool isDark;
  final VoidCallback onThemeToggle;
  HomeScreen({super.key, required this.isDark, required this.onThemeToggle});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    loadHabits();
  }
  //Load Habit Function
  Future<void> loadHabits() async {
    final prefs = await SharedPreferences.getInstance();

    String? savedData = prefs.getString('habits');

    if (savedData != null) {
      List data = jsonDecode(savedData);

      setState(() {
        habits = data.map((item) => item['name'] as String).toList();

        completed = data.map((item) => item['completed'] as bool).toList();

        habitIcons = data.map((item) {
          return IconData(
            item['icon'],
            fontFamily: 'MaterialIcons',
          );
        }).toList();
      });
    }
  }
  //Save Habit Function
  Future<void> saveHabits() async {
    final prefs = await SharedPreferences.getInstance();

    List data = List.generate(habits.length, (index) {
      return {
        'name': habits[index],
        'completed': completed[index],
        'icon': habitIcons[index].codePoint,
      };
    });

    await prefs.setString('habits', jsonEncode(data));
  }

  // EDIT HABIT FUNCTION
  void editHabit(int index) {
    TextEditingController controller =
    TextEditingController(text: habits[index]);
    IconData selectedIcon = habitIcons[index];
    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              backgroundColor: Theme.of(context).colorScheme.surface,
              title: Text(
                'Edit Habit',
                style: TextStyle(color: Theme.of(context).colorScheme.onSurface,),
              ),
              content: SizedBox(
                width: double.maxFinite,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      TextField(
                        controller: controller,
                        style: TextStyle(color: Theme.of(context).colorScheme.onSurface,),
                        decoration: InputDecoration(
                          hintText: 'Habit name',
                          hintStyle: TextStyle(color: Colors.grey),
                        ),
                      ),
                      SizedBox(height: 20),
                      Text(
                        'Choose an Icon',
                        style: TextStyle(
                          color: Color(0xFFD4AF37),
                        ),
                      ),
                      SizedBox(height: 12),
                      Wrap(
                        spacing: 12,
                        runSpacing: 12,
                        children: availableIcons.map((icon) {
                          return GestureDetector(
                            onTap: () {
                              setDialogState(() {
                                selectedIcon = icon;
                              });
                            },
                            child: Container(
                              padding: EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color: selectedIcon == icon
                                    ? Color(0xFFD4AF37)
                                    : Color(0xFF303030),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Icon(
                                icon,
                                color: selectedIcon == icon
                                    ? Colors.black
                                    : Colors.white,
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                    ],
                  ),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text('Cancel'),
                ),
                ElevatedButton(
                  onPressed: () {
                    if (controller.text.trim().isNotEmpty) {
                      setState(() {
                        habits[index] = controller.text.trim();
                        habitIcons[index] = selectedIcon;
                      });
                      saveHabits();
                      Navigator.pop(context);
                    }
                  },
                  child: Text('Save'),
                ),
              ],
            );
          },
        );
      },
    ).then((_) {
      controller.dispose();
    });
  }
// DELETE HABIT FUNCTION

  void deleteHabit(int index) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          backgroundColor: Theme.of(context).colorScheme.surface,
          title: Text(
            'Delete Habit?',
            style: TextStyle(color: Theme.of(context).colorScheme.onSurface,),
          ),
          content: Text(
            'Are you sure you want to delete this habit?',
            style: TextStyle(color: Colors.grey),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text('Cancel'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.redAccent,
              ),
              onPressed: () {
                setState(() {
                  habits.removeAt(index);
                  completed.removeAt(index);
                  habitIcons.removeAt(index);
                });
                saveHabits();
                Navigator.pop(context);
              },
              child: Text(
                'Delete',
                style: TextStyle(color: Theme.of(context).colorScheme.onSurface,),
              ),
            ),
          ],
        );
      },
    );
  }

  String getDailyQuote() {
    int day = DateTime.now()
        .difference(DateTime(DateTime.now().year, 1, 1))
        .inDays;

    return dailyQuotes[day % dailyQuotes.length];
  }

  List<String> dailyQuotes = [
    "Small steps every day lead to big results.",
    "Discipline is the bridge between goals and success.",
    "Be better than yesterday.",
    "Your future depends on what you do today.",
    "Great things take time. Keep going.",
    "Consistency is more important than perfection.",
    "Believe in yourself and keep moving forward.",
    "Every day is a new opportunity to grow.",
  ];
  List<IconData> availableIcons = [
    Icons.menu_book,
    Icons.water_drop,
    Icons.fitness_center,
    Icons.code,
    Icons.wb_sunny,
    Icons.directions_run,
    Icons.self_improvement,
    Icons.restaurant,
    Icons.bedtime,
    Icons.music_note,
    Icons.pets,
    Icons.favorite,
    Icons.work,
    Icons.sports_basketball,
    Icons.school,
    Icons.camera_alt,
  ];
  List<IconData> habitIcons = [
    Icons.menu_book,
    Icons.water_drop,
    Icons.fitness_center,
    Icons.code,
  ];
  List<String> habits = [
    'Read 10 Pages',
    'Drink 8 Glasses of Water',
    'Exercise 30 Minutes',
    'Learn Flutter',
  ];
  List<bool> completed = [false, false, false, false];


  int get totalHabits {
    return habits.length;
  }

  int get completedHabits {
    return completed.where((habit) => habit).length;
  }
  Widget build(BuildContext context) {
    double progress = completedHabits/ totalHabits;
    return Scaffold(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text('HabitFlow',
        style: TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 23,
        ),
        ),
        actions: [
          IconButton(
            onPressed: widget.onThemeToggle,
            icon: Icon(
              widget.isDark ? Icons.light_mode : Icons.dark_mode,
              color: Color(0xFFD4AF37),
            ),
            tooltip: 'Change Theme',
          ),

          Padding(
            padding: EdgeInsets.only(right: 16),
            child: Icon(
              Icons.person_outline,
              color: Color(0xFFD4AF37),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(20),
          child:
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Welcome Back!',
                style: TextStyle(
                    color: Theme.of(context).colorScheme.onSurface,
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 8),

               Text(
                "Let's make today count.",
                style: TextStyle(
                  color: Colors.grey,
                  fontSize: 15,
                ),
              ),

              SizedBox(height: 18),

// Daily Quote Card
              Container(
                width: double.infinity,
                padding: EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surface,
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(
                    color: Color(0xFFD4AF37),
                    width: 1,
                  ),
                ),
                child: Row(
                  children: [
                    Icon(
                      Icons.format_quote,
                      color: Color(0xFFD4AF37),
                      size: 30,
                    ),

                    SizedBox(width: 12),

                    Expanded(
                      child: Text(
                        getDailyQuote(),
                        style: TextStyle(
                          color: Theme.of(context).colorScheme.onSurface,
                          fontSize: 14,
                          fontStyle: FontStyle.italic,
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              SizedBox(height: 25),

              //Progress Card
              Container(
                width: double.infinity,
                padding: EdgeInsets.all(20),

                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.surface,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(
                    color: Color(0xFFD4AF37),
                    width: 1,
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,

                  children: [
                    Text("TODAY'S PROGRESS",
                    style: TextStyle(
                      color: Color(0xFFD4AF37),
                      fontSize: 13,
                    ),
                    ),
                    SizedBox(height: 12,),

                    Text(
                      '${(progress * 100).toInt()}%',
                      style:  TextStyle(
                          color: Theme.of(context).colorScheme.onSurface,
                        fontSize: 36,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 10,),

                    LinearProgressIndicator(
                      value: progress,
                      minHeight: 8,
                      backgroundColor: Colors.grey,
                      valueColor:
                        AlwaysStoppedAnimation(
                          Color(0xFFD4AF37),
                        ),
                    ),
                    SizedBox(height: 12,),

                     Text(
                      '$completedHabits of $totalHabits habits completed',
                      style: TextStyle(
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 30,),

               Text(
                "Today's Habits",
                style: TextStyle(
                    color: Theme.of(context).colorScheme.onSurface,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 15,),

              //Display Habits Dynamically
              ...List.generate(habits.length, (index) {
                return habitItem(
                    habits[index],
                    habitIcons[index],
                    index,
                );
              }),
            ],
          ),
          ),
      ),

      //Add Button
      floatingActionButton: FloatingActionButton(
        onPressed: addHabit,

        backgroundColor: Color(0xFFD4AF37),

        child: Icon(
          Icons.add,
          color: Colors.black,
        ),
      ),
    );
  }
  //ADD HABIT FUNCTION

  void addHabit() {
    TextEditingController controller = TextEditingController();

    IconData selectedIcon = Icons.star;

    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
                backgroundColor: Theme.of(context).colorScheme.surface,

              title: Text(
                'Add New Habit',
                style: TextStyle(color: Theme.of(context).colorScheme.onSurface,),
              ),

                content: SizedBox(
                    width: double.maxFinite,
                    child: SingleChildScrollView(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                  TextField(
                    controller: controller,
                    style: TextStyle(color: Theme.of(context).colorScheme.onSurface,),
                    decoration: InputDecoration(
                      hintText: 'Enter habit name',
                      hintStyle: TextStyle(color: Colors.grey),
                    ),
                  ),

                   SizedBox(height: 20),

                  Text(
                    'Choose an Icon',
                    style: TextStyle(color: Color(0xFFD4AF37)),
                  ),

                  SizedBox(height: 12),

                  Wrap(
                    spacing: 12,
                    runSpacing: 12,
                    children: availableIcons.map((icon) {
                      return GestureDetector(
                        onTap: () {
                          setDialogState(() {
                            selectedIcon = icon;
                          });
                        },

                        child: Container(
                          padding:  EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: selectedIcon == icon
                                ?  Color(0xFFD4AF37)
                                :  Color(0xFF303030),
                            borderRadius: BorderRadius.circular(10),
                          ),

                          child: Icon(
                            icon,
                            color: selectedIcon == icon
                                ? Colors.black
                                : Colors.white,
                          ),
                        ),
                      );
                    }).toList(),
                  ),
                ],
              ),
                    ),
                ),
              actions: [

                TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: const Text('Cancel'),
                ),

                ElevatedButton(
                  onPressed: () {
                    if (controller.text.trim().isNotEmpty) {

                      setState(() {
                        habits.add(controller.text.trim());
                        completed.add(false);
                        habitIcons.add(selectedIcon);
                      });
                      saveHabits();
                      Navigator.pop(context);
                    }
                  },

                  child:  Text('Add Habit'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  //Reusable Habit Widget

  Widget habitItem(String text, IconData icon, int index) {
    return Container(
      margin:  EdgeInsets.only(bottom: 12),
      padding:  EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surface,
        borderRadius: BorderRadius.circular(15),
      ),

      child: Row(
        children: [
          Icon(
            icon,
            color:  Color(0xFFD4AF37),
          ),

           SizedBox(width: 15),

          Expanded(
            child: Text(
              text,
              style: TextStyle(
                color: Theme.of(context).colorScheme.onSurface,
                fontSize: 15,
                decoration: completed[index]
                    ? TextDecoration.lineThrough
                    : TextDecoration.none,
              ),
            ),
          ),

          Checkbox(
            value: completed[index],
            activeColor: Color(0xFFD4AF37),

            onChanged: (value) {
              setState(() {
                completed[index] = value!;
              });

              saveHabits();
            },
          ),

          PopupMenuButton<String>(
            icon: Icon(
              Icons.more_vert,
              color: Color(0xFFD4AF37),
            ),

            color:Color(0xFF292929),

            onSelected: (value) {
              if (value == 'edit') {
                editHabit(index);
              } else if (value == 'delete') {
                deleteHabit(index);
              }
            },

            itemBuilder: (context) => [
              PopupMenuItem(
                value: 'edit',
                child: Row(
                  children: [
                    Icon(Icons.edit, color: Color(0xFFD4AF37)),
                    SizedBox(width: 10),
                    Text('Edit', style: TextStyle(color: Theme.of(context).colorScheme.onSurface,)),
                  ],
                ),
              ),

              PopupMenuItem(
                value: 'delete',
                child: Row(
                  children: [
                    Icon(Icons.delete, color: Colors.redAccent),
                    SizedBox(width: 10),
                    Text('Delete', style: TextStyle(color: Theme.of(context).colorScheme.onSurface,)),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
